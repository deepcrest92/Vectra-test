"""Get mimecast data and ingest to custom table in sentinel."""

import inspect
import datetime
import json
import time
from ..SharedCode import consts
from ..SharedCode.mimecast_exception import MimecastException, MimecastTimeoutException
from ..SharedCode.logger import applogger
from ..SharedCode.state_manager import StateManager
from ..SharedCode.utils import Utils
from ..SharedCode.sentinel import post_data


class MimecastDLPToSentinel(Utils):
    """Class for ingest the data from mimecast to sentinel."""

    def __init__(self, start_time) -> None:
        """Initialize MimecastDLPToSentinel object."""
        super().__init__(consts.SEG_DLP_FUNCTION_NAME)
        self.check_environment_var_exist(
            [
                {"File_Share_Name": consts.FILE_SHARE_NAME},
                {"Base_Url": consts.BASE_URL},
                {"WorkspaceID": consts.WORKSPACE_ID},
                {"WorkspaceKey": consts.WORKSPACE_KEY},
                {"Mimecast_Client_ID": consts.MIMECAST_CLIENT_ID},
                {"Mimecast_Client_Secret": consts.MIMECAST_CLIENT_SECRET},
            ]
        )
        self.authenticate_mimecast_api()
        self.start = start_time
        self.checkpoint_obj = StateManager(
            consts.CONN_STRING, consts.FILE_PATH, consts.FILE_SHARE_NAME
        )

    def get_mimecast_dlp_data_in_sentinel(self):
        """Get mimecast data and ingest data to sentinel, initialization method."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            from_date, to_date, page_token = self.get_from_date_to_date_page_token()
            while (
                self.iso_to_epoch_int(to_date) - self.iso_to_epoch_int(from_date)
                >= consts.TIME_DIFFERENCE
            ):
                if int(time.time()) >= self.start + consts.FUNCTION_APP_TIMEOUT_SECONDS:
                    raise MimecastTimeoutException()
                from_date, to_date = self.get_and_ingest_data_to_sentinel(
                    from_date, to_date, page_token
                )
            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "From and To time difference is less than 15 min, Stop execution.",
                )
            )
        except MimecastTimeoutException:
            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Mimecast: 9:00 mins executed hence breaking.",
                )
            )
            return
        except MimecastException:
            raise MimecastException()
        except Exception as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.UNEXPECTED_ERROR_MSG.format(err),
                )
            )
            raise MimecastException()

    def get_from_date_to_date_page_token(self):
        __method_name = inspect.currentframe().f_code.co_name
        try:
            checkpoint_data = self.get_checkpoint_data(self.checkpoint_obj)
            from_date = None
            page_token = ""
            to_date = None

            if not checkpoint_data:
                start_date = self.get_start_date_of_data_fetching()
                applogger.info(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        self.azure_function_name,
                        "Checkpoint data is not available, Start fetching data from = {}".format(
                            start_date
                        ),
                    )
                )
                from_date = start_date
                to_date = datetime.datetime.now(datetime.timezone.utc).strftime(
                    consts.DATE_TIME_FORMAT
                )
            else:
                from_date = checkpoint_data.get("from_date")
                page_token = checkpoint_data.get("page_token")
                to_date = checkpoint_data.get("to_date")

                if (not page_token and from_date):
                    to_date = datetime.datetime.now(datetime.timezone.utc).strftime(
                        consts.DATE_TIME_FORMAT
                    )
                
                if not to_date:
                    to_date = datetime.datetime.now(datetime.timezone.utc).strftime(
                        consts.DATE_TIME_FORMAT
                    )

                if not from_date:
                    start_date = self.get_start_date_of_data_fetching()
                    applogger.info(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            self.azure_function_name,
                            "From date is not available in checkpoint, Start fetching data from = {}".format(
                                start_date
                            ),
                        )
                    )
                    from_date = start_date
                # ! Add condition when page token is none and from and to date are not - change to date as current date
            return from_date, to_date, page_token
        except MimecastTimeoutException:
            raise MimecastTimeoutException()
        except MimecastException:
            raise MimecastException()
        except ValueError as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.VALUE_ERROR_MSG.format(err),
                )
            )
            raise MimecastException()
        except Exception as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.UNEXPECTED_ERROR_MSG.format(err),
                )
            )
            raise MimecastException()

    def get_start_date_of_data_fetching(self):
        __method_name = inspect.currentframe().f_code.co_name
        try:
            if not consts.START_DATE:
                start_date = (
                    datetime.datetime.utcnow()
                    - datetime.timedelta(days=consts.DEFAULT_LOOKUP_DAY)
                ).strftime(consts.DATE_TIME_FORMAT)
            else:
                try:
                    start_date = datetime.datetime.strptime(
                        consts.START_DATE, "%Y-%m-%d"
                    ).strftime(consts.DATE_TIME_FORMAT)
                    applogger.info(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            self.azure_function_name,
                            "Start date given by user = {}".format(start_date),
                        )
                    )
                except ValueError:
                    applogger.info(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            self.azure_function_name,
                            "Start date given by user is not valid = {}".format(
                                start_date
                            ),
                        )
                    )
                    start_date = (
                        datetime.datetime.utcnow()
                        - datetime.timedelta(days=consts.DEFAULT_LOOKUP_DAY)
                    ).strftime(consts.DATE_TIME_FORMAT)

            # * if start date is future date, consider default datetime
            if start_date > datetime.datetime.utcnow().strftime(
                consts.DATE_TIME_FORMAT
            ):
                applogger.info(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        self.azure_function_name,
                        "Start date given by user is future date = {}".format(
                            start_date
                        ),
                    )
                )
                start_date = (
                    datetime.datetime.utcnow()
                    - datetime.timedelta(days=consts.DEFAULT_LOOKUP_DAY)
                ).strftime(consts.DATE_TIME_FORMAT)
            return start_date
        except MimecastException:
            raise MimecastException()
        except Exception as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.UNEXPECTED_ERROR_MSG.format(err),
                )
            )
            raise MimecastException()

    def get_and_ingest_data_to_sentinel(self, from_date, to_date, page_token):
        __method_name = inspect.currentframe().f_code.co_name
        try:
            temp_from = from_date
            temp_to = to_date
            checkpoint_data_to_post = {
                "from_date": from_date,
                "to_date": to_date,
                "page_token": page_token,
            }
            page = 1
            total_ingested_data_count = 0
            while True:
                if int(time.time()) >= self.start + consts.FUNCTION_APP_TIMEOUT_SECONDS:
                    raise MimecastTimeoutException()
                payload = {
                    "meta": {
                        "pagination": {
                            "pageSize": consts.PAGE_SIZE,
                            "pageToken": "" if not page_token else page_token,
                        }
                    },
                    "data": [{"from": from_date, "oldestFirst": True, "to": to_date}],
                }
                applogger.debug(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        self.azure_function_name,
                        "Request body = {}".format(payload),
                    )
                )
                url = "{}{}".format(consts.BASE_URL, consts.ENDPOINTS["SEG_DLP"])
                response = self.make_rest_call("POST", url, json=payload)

                pagination_details = response.get("meta").get("pagination")
                page_token = pagination_details.get("next", "")
                total_count = pagination_details.get("totalCount")
                data_to_ingest = response.get("data")[0].get("dlpLogs")
                total_ingested_data_count += len(data_to_ingest)
                applogger.info(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        self.azure_function_name,
                        "Next Page token = {}, Total count = {}, Data count = {}, Ingested data count = {}, Page = {}".format(
                            page_token,
                            total_count,
                            len(data_to_ingest),
                            total_ingested_data_count,
                            page,
                        ),
                    )
                )
                if len(data_to_ingest) > 0:
                    post_data(json.dumps(data_to_ingest), consts.TABLE_NAME["SEG_DLP"])

                checkpoint_data_to_post.update({"page_token": page_token})
                if not page_token:
                    applogger.info(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            self.azure_function_name,
                            "No next page token found, Breaking the loop",
                        )
                    )
                    from_date = to_date
                    to_date = datetime.datetime.now(datetime.timezone.utc).strftime(
                        consts.DATE_TIME_FORMAT
                    )
                    checkpoint_data_to_post = {
                        "from_date": from_date,
                        "to_date": to_date,
                        "page_token": page_token,
                    }
                    self.post_checkpoint_data(
                        self.checkpoint_obj, checkpoint_data_to_post
                    )
                    break
                self.post_checkpoint_data(self.checkpoint_obj, checkpoint_data_to_post)
                page += 1
            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Data ingested from = {}, to = {}, Total ingested count = {}".format(
                        temp_from, temp_to, total_ingested_data_count
                    ),
                )
            )
            return from_date, to_date
        except MimecastTimeoutException:
            raise MimecastTimeoutException()
        except MimecastException:
            raise MimecastException()
        except ValueError as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.VALUE_ERROR_MSG.format(err),
                )
            )
            raise MimecastException()
        except TypeError as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.TYPE_ERROR_MSG.format(err),
                )
            )
            raise MimecastException()
        except Exception as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.UNEXPECTED_ERROR_MSG.format(err),
                )
            )
            raise MimecastException()
